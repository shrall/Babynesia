<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white p-4 flex items-center justify-between">
        <div class="flex flex-col gap-1">
            <span class="font-overpass text-3xl font-bold">Laporan Penjualan</span>
        </div>
    </div>
    <div class="w-full flex flex-col gap-y-4 p-4">
        
        <div class="admin-card">
            <div class="col-span-12">
                <table id="example" class="stripe hover" style="width:100%; padding-top: 1em; padding-bottom: 1em;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>Pembeli</th>
                            <th>Penerima</th>
                            <th>Subtotal</th>
                            <th>Diskon</th>
                            <th>Ongkos Kirim</th>
                            <th>Total</th>
                            <th>Bank</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $fakturs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faktur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($faktur->no_faktur); ?></td>
                                <td style="color: <?php echo e($faktur->fakturstatus->color); ?>;">
                                    <?php echo e($faktur->fakturstatus->status); ?></td>
                                <td><?php echo e($faktur->tanggal2); ?></td>
                                <td><?php echo e($faktur->receiver->receiver_name . ', ' . $faktur->receiver->city); ?></td>
                                <td><?php echo e($faktur->receiver->sender_name ?? config('app.name')); ?></td>
                                <td><?php echo e(AppHelper::rp($faktur->total_profit ?? 0)); ?></td>
                                <td><?php echo e(AppHelper::rp($faktur->discount ?? 0)); ?></td>
                                <td><?php echo e(AppHelper::rp($faktur->deliverycost ?? 0)); ?></td>
                                <td><?php echo e(AppHelper::rp($faktur->total_pembayaran ?? 0)); ?></td>
                                <td><?php echo e($faktur->payment ? $faktur->payment->info : '-'); ?></td>
                                <td>
                                    <div class="flex items-center justify-center gap-2">
                                        <a target="popup" href="<?php echo e(route('adminpage.faktur.show', $faktur->no_faktur)); ?>"
                                            onclick="window.open('<?php echo e(route('adminpage.faktur.show', $faktur->no_faktur)); ?>','name','width=700,height=550')"
                                            class="admin-action-button-info cursor-pointer">
                                            <span class="fa fa-fw fa-eye"></span>
                                        </a>
                                        <a target="blank" href="<?php echo e(route('adminpage.faktur.edit', $faktur->no_faktur)); ?>"
                                            class="admin-action-button-warning cursor-pointer">
                                            <span class="fa fa-fw fa-edit"></span>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php echo e($fakturs->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable({
                scrollX: true,
                "paging": false,
                "searching": false,
                "lengthChange": false,
                "info": false,
                "ordering": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/faktur/index.blade.php ENDPATH**/ ?>