<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white mb-2 p-4">
        <span class="font-overpass text-3xl font-bold">Tambah Kategori</span>
    </div>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <div class="admin-card">
            <div class="col-span-3">Nama Kategori</div>
            <div class="col-span-9 flex items-center gap-x-2">:
                <input type="text" name="" id="" class="admin-input">
            </div>
            <div class="col-span-12">
                <button type="submit" class="admin-button">Simpan</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/shop/category_create.blade.php ENDPATH**/ ?>