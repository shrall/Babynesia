<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white p-4 flex items-center justify-between">
        <div class="flex flex-col gap-1">
            <span class="font-overpass text-3xl font-bold">Daftar Kategori</span>
        </div>
        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('adminpage.kategori.create')); ?>" class="admin-button">Tambah Kategori</a>
            <a href="<?php echo e(route('adminpage.kategorichild.create')); ?>" class="admin-button">Tambah Subkategori</a>
        </div>
    </div>
    <div class="w-full flex flex-col gap-y-4 p-4">
        <div class="admin-card">
            <div class="col-span-12">
                <table id="example" class="stripe hover" style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
                    <thead>
                        <tr>
                            <th>Kategori</th>
                            <th>Subkategori</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="bg-blue-100"><?php echo e($kategori->nama_kategori); ?></td>
                                <td class="bg-blue-100"></td>
                                <td>
                                    <div class="flex items-center justify-center gap-2">
                                        <a target="blank"
                                            href="<?php echo e(route('adminpage.kategori.edit', $kategori->no_kategori)); ?>"
                                            class="admin-action-button-warning cursor-pointer">
                                            <span class="fa fa-fw fa-edit"></span>
                                        </a>
                                        <a onclick="event.preventDefault(); document.getElementById('delete-kategori-form-<?php echo e($kategori->no_kategori); ?>').submit();"
                                            class="admin-action-button-danger cursor-pointer">
                                            <span class="fa fa-fw fa-times"></span>
                                        </a>
                                        <form action="<?php echo e(route('adminpage.kategori.destroy', $kategori->no_kategori)); ?>"
                                            id="delete-kategori-form-<?php echo e($kategori->no_kategori); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input name="_method" type="hidden" value="DELETE">
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php $__currentLoopData = $kategori->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td class="bg-green-100"><?php echo e($sub->child_name); ?></td>
                                    <td>
                                        <div class="flex items-center justify-center gap-2">
                                            <a target="blank"
                                                href="<?php echo e(route('adminpage.kategorichild.edit', $sub->child_id)); ?>"
                                                class="admin-action-button-warning cursor-pointer">
                                                <span class="fa fa-fw fa-edit"></span>
                                            </a>
                                            <a onclick="event.preventDefault(); document.getElementById('delete-kategorichild-form-<?php echo e($sub->child_id); ?>').submit();"
                                                class="admin-action-button-danger cursor-pointer">
                                                <span class="fa fa-fw fa-times"></span>
                                            </a>
                                            <form
                                                action="<?php echo e(route('adminpage.kategorichild.destroy', $sub->child_id)); ?>"
                                                id="delete-kategorichild-form-<?php echo e($sub->child_id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input name="_method" type="hidden" value="DELETE">
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable({
                scrollX: true,
  "ordering": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/kategori/index.blade.php ENDPATH**/ ?>