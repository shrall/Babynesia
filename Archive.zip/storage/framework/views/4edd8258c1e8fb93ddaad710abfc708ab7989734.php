<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white mb-2 p-4">
        <span class="font-overpass text-3xl font-bold">Edit Produk</span>
    </div>
    <form action="<?php echo e(route('adminpage.produk.update', $produk->kode_produk)); ?>" method="post"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="grid grid-cols-2 gap-x-8 gap-y-2">
            <div class="admin-card">
                <div class="col-span-3">Kode Alias</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="text" name="alias_code" id="alias_code" class="admin-input"
                        value="<?php echo e($produk->kode_alias); ?>">
                </div>
                <div class="col-span-3">Status</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <div class="flex items-center gap-2">
                        <input type="radio" name="status" value="0" <?php echo e($produk->disable == '0' ? 'checked' : ''); ?>

                            id="radio-1">
                        <label for="radio-1">Aktif</label>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="radio" name="status" value="1" <?php echo e($produk->disable == '1' ? 'checked' : ''); ?>

                            id="radio-2">
                        <label for="radio-2">Tidak Aktif</label>
                    </div>
                </div>
                <div class="col-span-3">Nama Produk</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="text" name="name" id="name" class="admin-input" value="<?php echo e($produk->nama_produk); ?>"
                        required>
                </div>
                <div class="col-span-3">Kategori</div>
                <div class="col-span-9 flex gap-x-2">
                    <select name="category" id="category" class="admin-input">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($produk->kategory == $kategori->no_kategori ? 'selected' : ''); ?>

                                value="<?php echo e($kategori->no_kategori); ?>"><?php echo e($kategori->nama_kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-span-3">Merk</div>
                <div class="col-span-9 flex gap-x-2">
                    <select name="brand" id="brand" class="admin-input">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($produk->brand_produk == $brand->no_brand ? 'selected' : ''); ?>

                                value="<?php echo e($brand->no_brand); ?>"><?php echo e($brand->nama_brand); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-span-3">Berat</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="weight" id="weight" class="admin-input" value="<?php echo e($produk->weight); ?>">
                    gram
                </div>
                <div class="col-span-3">No Urut</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="order" id="order" class="admin-input" value="<?php echo e($produk->sort_nr); ?>">
                </div>
                <div class="col-span-3">HPP</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="hpp" id="hpp" class="admin-input" value="<?php echo e($produk->hpp); ?>">rupiah
                </div>
                <div class="col-span-3">Harga Web</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="harga" id="harga" class="admin-input" value="<?php echo e($produk->harga); ?>"
                        placeholder="*Bila 0, tidak ditampilkan">rupiah
                </div>
                <div class="col-span-3">Harga Toko</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="harga_toko" id="harga_toko" class="admin-input"
                        value="<?php echo e($produk->harga_toko); ?>" placeholder="*Bila 0, tidak ditampilkan">rupiah
                </div>
                <div class="col-span-3">Harga Grosir</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="harga_grosir" id="harga_grosir" class="admin-input"
                        value="<?php echo e($produk->harga_grosir); ?>" required>rupiah
                </div>
                <div class="col-span-3">Diskon 1</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="disc1" id="disc1" class="admin-input" value="<?php echo e($produk->disc1); ?>">%
                </div>
                <div class="col-span-3">Diskon 2</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="disc2" id="disc2" class="admin-input" value="<?php echo e($produk->disc2); ?>">%
                </div>
                <div class="col-span-3">Diskon 3</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="disc3" id="disc3" class="admin-input" value="<?php echo e($produk->disc3); ?>">%
                </div>

            </div>
            <div class="admin-card">
                <?php if(session('image')): ?>
                    <div class="rounded-lg col-span-12 bg-red-400 text-white p-4 mb-4">
                        <span class="fa fa-fw fa-info-circle ml-2"></span>
                        <?php echo e(session('image')); ?>

                    </div>
                <?php endif; ?>
                <div class="col-span-3">Gambar 1</div>
                <div class="col-span-9">
                    <?php if($produk->image): ?>
                        <div class="flex items-center gap-2">
                            <img src="<?php echo e('http://www.tokobayifiv.com/images/produk/'); ?><?php echo e($produk->image ?? '#'); ?>"
                                class="w-12 h-12 object-cover">
                            <input type="checkbox" name="deleteimg[0]">
                            Hapus Gambar
                            <input type="radio" name="image_primary" value="0" checked id="">
                            Gambar Utama
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-2">
                            <input type="file" name="image[0]" id="0-image" class="" accept="image/*">
                            <input type="radio" name="image_primary" value="0" id="">
                            Gambar Utama
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-span-3">Gambar 2</div>
                <div class="col-span-9">
                    <?php if($produk->images->count() == 2): ?>
                        <div class="flex items-center gap-2">
                            <img src="<?php echo e('http://www.tokobayifiv.com/images/produk/'); ?><?php echo e($produk->images[1] ?? '#'); ?>"
                                class="w-12 h-12 object-cover">
                            <input type="checkbox" name="deleteimg[1]">
                            Hapus Gambar
                            <input type="radio" name="image_primary" value="1" checked id="">
                            Gambar Utama
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-2">
                            <input type="file" name="image[1]" id="1-image" class="" accept="image/*">
                            <input type="radio" name="image_primary" value="1" id="">
                            Gambar Utama
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-span-3">Gambar 3</div>
                <div class="col-span-9">
                    <?php if($produk->images->count() == 3): ?>
                        <div class="flex items-center gap-2">
                            <img src="<?php echo e('http://www.tokobayifiv.com/images/produk/'); ?><?php echo e($produk->images[1] ?? '#'); ?>"
                                class="w-12 h-12 object-cover">
                            <input type="checkbox" name="deleteimg[2]">
                            Hapus Gambar
                            <input type="radio" name="image_primary" value="2" checked id="">
                            Gambar Utama
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-2">
                            <input type="file" name="image[2]" id="2-image" class="" accept="image/*">
                            <input type="radio" name="image_primary" value="2" id="">
                            Gambar Utama
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-span-3">Gambar 4</div>
                <div class="col-span-9">
                    <?php if($produk->images->count() == 4): ?>
                        <div class="flex items-center gap-2">
                            <img src="<?php echo e('http://www.tokobayifiv.com/images/produk/'); ?><?php echo e($produk->images[1] ?? '#'); ?>"
                                class="w-12 h-12 object-cover">
                            <input type="checkbox" name="deleteimg[3]">
                            Hapus Gambar
                            <input type="radio" name="image_primary" value="3" checked id="">
                            Gambar Utama
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-2">
                            <input type="file" name="image[3]" id="3-image" class="" accept="image/*">
                            <input type="radio" name="image_primary" value="3" id="">
                            Gambar Utama
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-span-3">Gambar 5</div>
                <div class="col-span-9">
                    <?php if($produk->images->count() == 5): ?>
                        <div class="flex items-center gap-2">
                            <img src="<?php echo e('http://www.tokobayifiv.com/images/produk/'); ?><?php echo e($produk->images[1] ?? '#'); ?>"
                                class="w-12 h-12 object-cover">
                            <input type="checkbox" name="deleteimg[4]">
                            Hapus Gambar
                            <input type="radio" name="image_primary" value="4" checked id="">
                            Gambar Utama
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-2">
                            <input type="file" name="image[4]" id="4-image" class="" accept="image/*">
                            <input type="radio" name="image_primary" value="4" id="">
                            Gambar Utama
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-span-3">Featured Product</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <div class="flex items-center gap-2">
                        <input type="radio" name="featured" value="0" <?php echo e($produk->featured == '0' ? 'checked' : ''); ?>

                            id="radio-3">
                        <label for="radio-3">Normal</label>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="radio" name="featured" value="1" <?php echo e($produk->featured == '1' ? 'checked' : ''); ?>

                            id="radio-4">
                        <label for="radio-4">Featured</label>
                    </div>
                </div>
                <div class="col-span-3">Status Promo</div>
                <div class="col-span-12 grid grid-cols-3 items-center gap-x-2">
                    <div class="flex items-center gap-2">
                        <input type="radio" name="stat" checked id="radio-5" value="0"
                            <?php echo e($produk->stat == '0' ? 'checked' : ''); ?>>
                        <label for="radio-5">Ready Stock</label>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="radio" name="stat" id="radio-6" value="r"
                            <?php echo e($produk->stat == 'r' ? 'checked' : ''); ?>>
                        <label for="radio-6">Restock Ready</label>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="radio" name="stat" id="radio-7" value="d"
                            <?php echo e($produk->stat == 'd' ? 'checked' : ''); ?>>
                        <label for="radio-7">Promo</label>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="radio" name="stat" id="radio-8" value="grd"
                            <?php echo e($produk->stat == 'grd' ? 'checked' : ''); ?>>
                        <label for="radio-8">Grosir Ready Stock</label>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="radio" name="stat" id="radio-9" value="gpo"
                            <?php echo e($produk->stat == 'gpo' ? 'checked' : ''); ?>>
                        <label for="radio-9">Grosir PO</label>
                    </div>
                </div>
                <div class="col-span-3">Harga Promo</div>
                <div class="col-span-9 flex items-center gap-x-2">
                    <input type="number" name="harga_sale" id="harga_sale" class="admin-input"
                        value="<?php echo e($produk->harga_sale); ?>" placeholder="*Bila 0, tidak ditampilkan">rupiah
                </div>
            </div>
            <div class="admin-card col-span-2">
                <div class="grid grid-cols-12 gap-y-1 col-span-12">
                    <div class="bg-slate-800 text-white flex p-4 col-span-2">Kode Stok</div>
                    <div class="bg-slate-800 text-white flex p-4 col-span-2">Type</div>
                    <div class="bg-slate-800 text-white flex p-4 col-span-2">Ukuran</div>
                    <div class="bg-slate-800 text-white flex p-4 col-span-2">Warna</div>
                    <div class="bg-slate-800 text-white flex p-4 col-span-1">Stok Sisa</div>
                    <div class="bg-slate-800 text-white flex p-4 col-span-1">Stok Dipesan</div>
                    <div class="bg-slate-800 text-white flex p-4 col-span-2">Action</div>
                </div>
                <div class="grid grid-cols-12 gap-2 justify-items-center col-span-12" id="product-stock-field">
                    <?php $__currentLoopData = $produk->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" name="stock_code[<?php echo e($loop->iteration); ?>]" value="<?php echo e($stok->id); ?>"
                            readonly class="admin-input-full col-span-2 stock-input-<?php echo e($loop->iteration); ?>">
                        <input type="text" name="stock_type[<?php echo e($loop->iteration); ?>]" value="<?php echo e($stok->type); ?>"
                            class="admin-input-full col-span-2 stock-input-<?php echo e($loop->iteration); ?>">
                        <input type="text" name="stock_size[<?php echo e($loop->iteration); ?>]" value="<?php echo e($stok->size); ?>"
                            class="admin-input-full col-span-2 stock-input-<?php echo e($loop->iteration); ?>">
                        <input type="text" name="stock_color[<?php echo e($loop->iteration); ?>]" value="<?php echo e($stok->color); ?>"
                            class="admin-input-full col-span-2 stock-input-<?php echo e($loop->iteration); ?>">
                        <input type="text" name="stock_left[<?php echo e($loop->iteration); ?>]" value="<?php echo e($stok->product_stock); ?>"
                            class="admin-input-full col-span-1 stock-input-<?php echo e($loop->iteration); ?>">
                        <?php
                            $orderedstock = 0;
                        ?>
                        <?php $__currentLoopData = $stok->fakturs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faktur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $orderedstock += $faktur->jumlah;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" name="stock_ordered[<?php echo e($loop->iteration); ?>]" value="<?php echo e($orderedstock); ?>"
                            readonly class="admin-input-full col-span-1 stock-input-<?php echo e($loop->iteration); ?>">
                        <a onclick="deleteType(<?php echo e($loop->iteration); ?>);"
                            class="admin-action-button-danger cursor-pointer col-span-2 stock-input-<?php echo e($loop->iteration); ?>">
                            <span class="fa fa-fw fa-trash-alt"></span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-span-12 flex mx-auto" onclick="addType();">
                    <div class="admin-button"><span class="fa fa-fw fa-plus"></span>Tambah Jenis Produk</div>
                </div>
            </div>
            <input type="hidden" name="product_types" id="product-types" value="<?php echo e($produk->stocks->count()); ?>">
            <div class="admin-card col-span-2">
                <div class="col-span-3">Isi</div>
                <div class="col-span-12 flex justify-center items-center gap-x-2">
                    <textarea type="text" name="content" id="input-content" class="admin-input"><?php echo e($produk->ket); ?></textarea>
                </div>
                <div class="col-span-12">
                    <div class="flex items-center gap-x-2">
                        <button type="submit" class="admin-button">Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
    <script>
        ClassicEditor.create(document.querySelector('#input-content'), {
                mediaEmbed: {
                    previewsInData: true
                },
                removePlugins: ['CKFinderUploadAdapter', 'CKFinder', 'EasyImage', 'Image', 'ImageCaption', 'ImageStyle',
                    'ImageToolbar', 'ImageUpload', 'MediaEmbed', 'Table'
                ],
            }).then(editor => {})
            .catch(error => {
                console.error(error);
                console.error(error.stack);
            });
        ClassicEditor.editorConfig = function(config) {
            // misc options
            config.height = '350px';
        };
    </script>
    <script>
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var hostname = "<?php echo e(request()->getHost()); ?>"
        var url = ""
        if (hostname.includes('www')) {
            url = "https://" + hostname
        } else {
            url = "<?php echo e(config('app.url')); ?>"
        }
        var prodstok = <?php echo json_encode($produk->stocks->count(), 15, 512) ?>;

        function addType() {
            prodstok++;
            refresh_type();
        }

        function deleteType(order) {
            $('.stock-input-' + order).remove();
        }

        function refresh_type() {
            $.post(url + "/adminpage/produk/add_type", {
                    _token: CSRF_TOKEN,
                    prodstok: prodstok
                })
                .done(function(data) {
                    $('#product-stock-field').append(data);
                })
                .fail(function(error) {
                    console.log(error);
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/produk/edit.blade.php ENDPATH**/ ?>