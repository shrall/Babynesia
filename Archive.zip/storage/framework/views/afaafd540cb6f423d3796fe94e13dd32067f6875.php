<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white p-4 flex items-center justify-between">
        <div class="flex flex-col gap-1">
            <span class="font-overpass text-3xl font-bold">Hit Counter</span>
            <span class="text-gray-400">Laporan jumlah pengunjung website.</span>
        </div>
    </div>
    <div class="w-full flex flex-col gap-y-4 p-4">
        <div class="admin-card">
            <div class="col-span-12">
                <table id="example" class="stripe hover" style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
                    <thead>
                        <tr>
                            <th data-priority="1">No</th>
                            <th data-priority="2">Bulan</th>
                            <th data-priority="3">Pengunjung - Anggota</th>
                            <th data-priority="4">Pengunjung - Bukan Anggota</th>
                            <th data-priority="5">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $hitcounters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hitcounter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($hitcounter->id); ?></td>
                                <td><?php echo e($hitcounter->month); ?></td>
                                <td><?php echo e($hitcounter->registered); ?></td>
                                <td><?php echo e($hitcounter->unregistered); ?></td>
                                <td><?php echo e($hitcounter->total); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable({
                scrollX: true,
                "order": [
                    [1, "desc"]
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/settings/hitcounter.blade.php ENDPATH**/ ?>