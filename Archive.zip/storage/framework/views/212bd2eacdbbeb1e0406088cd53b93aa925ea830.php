<?php $__env->startSection('title', 'TokoBayiFiv'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('inc.navbar1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div
    class="xl:grid xl:grid-cols-4 xl:grid-flow-row-dense xl:gap-3 container mx-auto xl:px-40 px-3 xl:pt-6 xl:pb-10 pt-3 pb-5">
    <div>
        <div class="w-full bg-white rounded-md shadow-sm pt-3 pb-7 px-3">
            <div>
                <input type="radio" name="test" onclick="showcontent()" id="profile" value="profile" class="peer" checked hidden>
                <label for="profile" type="button"
                    class="appearance-none peer-checked:font-bold peer-checked:text-sky-500 cursor-pointer font-encode-sans text-slate-900 hover:text-sky-500 text-sm sm:text-base ">
                    Profile Info
                </label>
            </div>
            <hr class="my-3">
            <div>
                <input type="radio" name="test" onclick="showcontent()" id="editprofile" value="edit-profile" class="peer" hidden>
                <label for="editprofile" type="button"
                    class="appearance-none peer-checked:font-bold peer-checked:text-sky-500 cursor-pointer font-encode-sans text-slate-900 hover:text-sky-500 text-sm sm:text-base ">
                    Edit Profile
                </label>
            </div>
            <hr class="my-3">
            <div>
                <input type="radio" name="test" onclick="showcontent()" id="history" value="history" class="peer" hidden>
                <label for="history" type="button"
                    class="appearance-none peer-checked:font-bold peer-checked:text-sky-500 cursor-pointer font-encode-sans text-slate-900 hover:text-sky-500 text-sm sm:text-base ">
                    History Transaksi
                </label>
            </div>

            <hr class="my-3">
            <a href="#" type="button" class="appearance-none font-encode-sans text-slate-900 hover:text-sky-500 text-sm sm:text-base ">
                Chat Us
            </a>
            <hr class="my-3">
            <form action="<?php echo e(route('logout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="font-encode-sans text-red-500 hover:text-red-600 text-sm sm:text-base ">
                    Logout
                </button>
            </form>

        </div>
    </div>

    <div id="profile_info" class="hidden w-full mt-3 xl:mt-0 xl:col-span-3 bg-white rounded-md shadow-sm pt-3 pb-7 px-3">
        <h1 class="font-concert-one text-sky-500 text-3xl sm:text-4xl">
            Profile Info
        </h1>
        <hr class="my-3">
        <div class="flex">
            <i class="fa fa-user-circle size sm:text-8xl text-6xl text-sky-500"></i>
            <div class="ml-4">
                <div class="sm:mt-4">
                    <h1 class="font-concert-one text-pink-400 text-3xl sm:text-4xl">
                        <?php echo e(Auth::user()->name); ?>

                    </h1>
                    <p class="mt-1 font-encode-sans text-gray-400 text-sm sm:text-base">
                        <?php echo e(Auth::user()->email); ?>

                    </p>
                </div>
                <div class="mt-6">
                    <p class="font-encode-sans text-gray-400 text-sm sm:text-base">
                        Address
                    </p>
                    <p class="font-encode-sans text-slate-900 text-sm sm:text-base">
                        <?php echo e(Auth::user()->alamat); ?>

                    </p>
                </div>
                <div class="mt-4 flex">
                    <div>
                        <div>
                            <p class="font-encode-sans text-gray-400 text-sm sm:text-base">
                                City
                            </p>
                            <p class="font-encode-sans font-bold text-slate-900 text-sm sm:text-base">
                                <?php echo e(Auth::user()->kota); ?>

                            </p>
                        </div>
                        <div class="mt-4">
                            <p class="font-encode-sans text-gray-400 text-sm sm:text-base">
                                Phone
                            </p>
                            <p class="font-encode-sans font-bold text-slate-900 text-sm sm:text-base">
                                <?php echo e(Auth::user()->telp); ?>

                            </p>
                        </div>
                    </div>
                    <div class="ml-20 xl:ml-48">
                        <div>
                            <p class="font-encode-sans text-gray-400 text-sm sm:text-base">
                                Province
                            </p>
                            <p class="font-encode-sans font-bold text-slate-900 text-sm sm:text-base">
                                <?php echo e(Auth::user()->propinsi); ?>

                            </p>
                        </div>
                        <div class="mt-4">
                            <p class="font-encode-sans text-gray-400 text-sm sm:text-base">
                                Handphone
                            </p>
                            <p class="font-encode-sans font-bold text-slate-900 text-sm sm:text-base">
                                <?php echo e(Auth::user()->hp); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="profile_edit" class="hidden w-full mt-3 xl:mt-0 xl:col-span-3 bg-white rounded-md shadow-sm pt-3 pb-7 px-3">
        <h1 class="font-concert-one text-sky-500 text-3xl sm:text-4xl">
            Edit Profile
        </h1>
        <hr class="my-3">
        <form method="POST" action="<?php echo e(route('register')); ?>" class="mt-7">
            <?php echo csrf_field(); ?>

            <h6 class="font-encode-sans font-bold mt-7 text-slate-900">
                Personal Data
            </h6>

            <div class="mt-4 grid grid-cols-2 gap-3">
                <div class="w-full">
                    <div> <label for="name" class="text-sm sm:text-base font-encode-sans text-slate-900">Name</label>
                    </div>
                    <input id="name" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                        name="name" value="<?php echo e(Auth::user()->name); ?>" required>

                </div>
                <div class="w-full">
                    <div> <label for="last-name" class="text-sm sm:text-base font-encode-sans text-slate-900">Last
                            Name</label>
                    </div>
                    <input id="last-name" type="text"
                        class="appearance-none border p-1 w-full rounded-md border-sky-500" required
                        value="<?php echo e(Auth::user()->lastname); ?>" name="lastname">
                </div>
            </div>
            <div class="mt-4">
                <div> <label for="address" class="text-sm sm:text-base font-encode-sans text-slate-900">Address</label>
                </div>
                <textarea id="address" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="alamat" required><?php echo e(Auth::user()->alamat); ?></textarea>
            </div>
            <div class="mt-4">
                <div> <label for="city" class="text-sm sm:text-base font-encode-sans text-slate-900">City</label>
                </div>
                <input id="city" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="kota" required value="<?php echo e(Auth::user()->kota); ?>">
            </div>
            <div class="mt-4">
                <div> <label for="postcode"
                        class="text-sm sm:text-base font-encode-sans text-slate-900">Postcode</label>
                </div>
                <input id="postcode" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="kodepos" required value="<?php echo e(Auth::user()->kodepos); ?>">
            </div>
            <div class="mt-4">
                <div> <label for="country" class="text-sm sm:text-base font-encode-sans text-slate-900">Country</label>
                </div>
                <select id="country" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="negara">
                    <option hidden value="<?php echo e(Auth::user()->negara); ?>"><?php echo e(Auth::user()->negara); ?></option>
                    <option value="Indonesia">Indonesia</option>
                </select>
            </div>
            <div class="mt-4">
                <div> <label for="provinsi-indo"
                        class="text-sm sm:text-base font-encode-sans text-slate-900">Provinsi</label>
                </div>
                <select id="provinsi-indo" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="propinsi">
                    <option hidden value="<?php echo e(Auth::user()->propinsi); ?>"><?php echo e(Auth::user()->propinsi); ?></option>
                    <option value="Indonesia"> Indonesia</option>
                </select>
            </div>
            <div class="mt-4">
                <div> <label for="provinsi-notindo"
                        class="text-sm sm:text-base font-encode-sans text-slate-900">Provinsi (Selain Indonesia)</label>
                </div>
                <input id="provinsi-notindo" type="text"
                    class="appearance-none border p-1 w-full rounded-md border-sky-500" name="propinsi2"
                    value="<?php echo e(Auth::user()->propinsi); ?>">
            </div>
            <div class="mt-4">
                <div> <label for="phone" class="text-sm sm:text-base font-encode-sans text-slate-900">Phone</label>
                </div>
                <input id="phone" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="telp" required value="<?php echo e(Auth::user()->telp); ?>">
            </div>
            <div class="mt-4">
                <div> <label for="mobile" class="text-sm sm:text-base font-encode-sans text-slate-900">Mobile</label>
                </div>
                <input id="mobile" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="hp" required value="<?php echo e(Auth::user()->hp); ?>">
            </div>
            <h6 class="mt-7 font-encode-sans font-bold text-slate-900">
                Login and Password
            </h6>
            <div class="mt-4">
                <div>
                    <label for="email"
                        class="text-sm sm:text-base font-encode-sans text-slate-900"><?php echo e(__('Email Address')); ?></label>
                </div>

                <input id="email" type="email"
                    class="appearance-none border p-1 rounded-md w-full border-sky-500 disabled:bg-neutral-100 disabled:border-gray-400 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                    value="<?php echo e(Auth::user()->email); ?>" disabled>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback text-red-500 font-normal font-encode-sans text-sm sm:text-base"
                    role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-4">
                <div> <label for="password"
                        class="text-sm sm:text-base font-encode-sans text-slate-900"><?php echo e(__('Password')); ?></label>
                </div>
                <input id="password" type="password"
                    class="appearance-none border p-1 w-full rounded-md border-sky-500 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password" required autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback text-red-500 font-normal font-encode-sans text-sm sm:text-base"
                    role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="mt-4">
                <div> <label for="password-confirm"
                        class="text-sm sm:text-base font-encode-sans text-slate-900"><?php echo e(__('Confirm Password')); ?></label>
                </div>
                <input id="password-confirm" type="password"
                    class="appearance-none border p-1 w-full rounded-md border-sky-500 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password_confirmation" required autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback text-red-500 font-normal font-encode-sans text-sm sm:text-base"
                    role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="mt-7 text-center">
                <button type="submit"
                    class="border-2 border-pink-400 font-bold font-encode-sans text-pink-400 px-8 py-2 rounded-full">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    let profileCheck = document.getElementById("profile");
    let editCheck = document.getElementById("editprofile");
    let historyCheck = document.getElementById("history");

    let profile_info = document.getElementById("profile_info");
    let profile_edit = document.getElementById("profile_edit");

    if(profileCheck.checked) {
        profile_info.style.display = "block";
        profile_edit.style.display = "none";
    }

    function showcontent() {
        if(profileCheck.checked) {
            profile_info.style.display = "block";
            profile_edit.style.display = "none";
        }
        else if(editCheck.checked) {
            profile_edit.style.display = "block";
            profile_info.style.display = "none";
        }
    }

    
</script>

<?php echo $__env->make('inc.footer1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/user/profile.blade.php ENDPATH**/ ?>