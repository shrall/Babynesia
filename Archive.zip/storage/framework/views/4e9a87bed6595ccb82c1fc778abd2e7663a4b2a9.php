<?php $__env->startSection('content'); ?>
<div class="container min-h-screen sm:flex sm:justify-center px-3 pt-4">
    <div class="bg-white rounded-lg sm:w-vw-70 xl:w-vw-50 shadow-md sm:py-5 sm:px-8 px-3 py-4">
        <h1 class="font-concert-one text-3xl sm:text-4xl text-center text-sky-500">Registration</h1>
        <p class="text-gray-400 font-encode-sans text-sm sm:text-base text-clip mt-3">
            Dengan melakukan registrasi, maka data Anda akan tersimpan dalam sistem kami.
            Untuk selanjutnya bila Anda berbelanja, Anda hanya perlu login dan tidak perlu setiap kali mengisi ulang
            alamat dan data lainnya.
            <br> <br>
            Data yang Anda berikan TIDAK akan diberikan kepada pihak lain untuk kepentingan APAPUN juga.
            Untuk menjaga kepercayaan Anda, kami akan menjaga kerahasiaan data Anda.
        </p>

        <form method="POST" action="<?php echo e(route('register')); ?>" class="mt-7">
            <?php echo csrf_field(); ?>
            <h6 class="font-encode-sans font-bold text-slate-900">
                Login and Password
            </h6>
            <div class="mt-4">
                <div>
                    <label for="email"
                        class="text-sm sm:text-base font-encode-sans text-slate-900"><?php echo e(__('Email Address')); ?></label>
                </div>

                <input id="email" type="email"
                    class="appearance-none border p-1 rounded-md w-full border-sky-500 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback text-red-500 font-normal font-encode-sans text-sm sm:text-base" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mt-4">
                <div> <label for="password"
                        class="text-sm sm:text-base font-encode-sans text-slate-900"><?php echo e(__('Password')); ?></label>
                </div>
                <input id="password" type="password"
                    class="appearance-none border p-1 w-full rounded-md border-sky-500 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password" required autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback text-red-500 font-normal font-encode-sans text-sm sm:text-base" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="mt-4">
                <div> <label for="password-confirm"
                        class="text-sm sm:text-base font-encode-sans text-slate-900"><?php echo e(__('Confirm Password')); ?></label>
                </div>
                <input id="password-confirm" type="password"
                    class="appearance-none border p-1 w-full rounded-md border-sky-500 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password_confirmation" required autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback text-red-500 font-normal font-encode-sans text-sm sm:text-base" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <h6 class="font-encode-sans font-bold mt-7 text-slate-900">
                Personal Data
            </h6>

            <div class="mt-4 grid grid-cols-2 gap-3">
                <div class="w-full">
                    <div> <label for="name" class="text-sm sm:text-base font-encode-sans text-slate-900">Name</label>
                    </div>
                    <input id="name" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                        name="name">

                </div>
                <div class="w-full">
                    <div> <label for="last-name" class="text-sm sm:text-base font-encode-sans text-slate-900">Last
                            First Name</label>
                    </div>
                    <input id="last-name" type="text"
                        class="appearance-none border p-1 w-full rounded-md border-sky-500" name="lastname">
                </div>
            </div>
            <div class="mt-4">
                <div> <label for="address" class="text-sm sm:text-base font-encode-sans text-slate-900">Address</label>
                </div>
                <textarea id="address" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="alamat"></textarea>
            </div>
            <div class="mt-4">
                <div> <label for="city" class="text-sm sm:text-base font-encode-sans text-slate-900">City</label>
                </div>
                <input id="city" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="kota">
            </div>
            <div class="mt-4">
                <div> <label for="postcode"
                        class="text-sm sm:text-base font-encode-sans text-slate-900">Postcode</label>
                </div>
                <input id="postcode" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="kodepos">
            </div>
            <div class="mt-4">
                <div> <label for="country" class="text-sm sm:text-base font-encode-sans text-slate-900">Country</label>
                </div>
                <select id="country" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="negara">
                    <option value="Indonesia">Indonesia</option>
                </select>
            </div>
            <div class="mt-4">
                <div> <label for="provinsi-indo"
                        class="text-sm sm:text-base font-encode-sans text-slate-900">Provinsi</label>
                </div>
                <select id="provinsi-indo" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="propinsi">
                    <option value="Indonesia"> Indonesia</option>
                </select>
            </div>
            <div class="mt-4">
                <div> <label for="provinsi-notindo"
                        class="text-sm sm:text-base font-encode-sans text-slate-900">Provinsi (Selain Indonesia)</label>
                </div>
                <input id="provinsi-notindo" type="text"
                    class="appearance-none border p-1 w-full rounded-md border-sky-500" name="kodepos">
            </div>
            <div class="mt-4">
                <div> <label for="phone" class="text-sm sm:text-base font-encode-sans text-slate-900">Phone</label>
                </div>
                <input id="phone" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="telp">
            </div>
            <div class="mt-4">
                <div> <label for="mobile" class="text-sm sm:text-base font-encode-sans text-slate-900">Mobile</label>
                </div>
                <input id="mobile" type="text" class="appearance-none border p-1 w-full rounded-md border-sky-500"
                    name="hp">
            </div>

            <div class="mt-7 text-center">
                <button type="submit"
                    class="border-2 border-pink-400 font-bold font-encode-sans text-pink-400 px-8 py-2 rounded-full">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>
            <div class="text-center mt-3">
                <a class="text-sm sm:text-base text-sky-500 font-encode-sans text-center" href="<?php echo e(route('login')); ?>">
                    <?php echo e(__('Sudah punya akun? Login sekarang')); ?>

                </a>
            </div>
        </form>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/auth/register.blade.php ENDPATH**/ ?>