<input type="text" name="stock_code[<?php echo e($order); ?>]" readonly
    class="admin-input-full stock-input-<?php echo e($order); ?> col-span-2">
<input type="text" name="stock_type[<?php echo e($order); ?>]"
    class="admin-input-full stock-input-<?php echo e($order); ?> col-span-2">
<input type="text" name="stock_size[<?php echo e($order); ?>]"
    class="admin-input-full stock-input-<?php echo e($order); ?> col-span-2">
<input type="text" name="stock_color[<?php echo e($order); ?>]"
    class="admin-input-full stock-input-<?php echo e($order); ?> col-span-2">
<input type="text" name="stock_left[<?php echo e($order); ?>]"
    class="admin-input-full stock-input-<?php echo e($order); ?> col-span-1">
<input type="text" name="stock_ordered[<?php echo e($order); ?>]" readonly
    class="admin-input-full stock-input-<?php echo e($order); ?> col-span-1">
<a onclick="deleteType(<?php echo e($order); ?>);"
    class="admin-action-button-danger cursor-pointer col-span-2 stock-input-<?php echo e($order); ?>">
    <span class="fa fa-fw fa-trash-alt"></span>
</a>
<?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/produk/inc/newstockfield.blade.php ENDPATH**/ ?>