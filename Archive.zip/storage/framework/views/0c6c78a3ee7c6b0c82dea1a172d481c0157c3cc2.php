<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white p-4 flex items-center justify-between">
        <div class="flex flex-col gap-1">
            <span class="font-overpass text-3xl font-bold">Nota Penjualan - <?php echo e($faktur->no_faktur); ?></span>
        </div>
    </div>
    <form action="<?php echo e(route('adminpage.faktur.update', $faktur->no_faktur)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="w-full flex flex-col gap-y-4 p-4">
            <div class="admin-card">
                <div class="col-span-3 place-self-start">Status</div>
                <?php if($faktur->status != 3 && $faktur->status != 5): ?>
                    <div class="col-span-9">
                        <div class="flex flex-col gap-1">
                            <?php $__currentLoopData = $fakturstatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center gap-2">
                                    <input type="radio" name="faktur_status" value="<?php echo e($fs->id); ?>"
                                        <?php echo e($fs->id == $faktur->status ? 'checked' : ''); ?> id="radio-fs-<?php echo e($fs->id); ?>">
                                    <label for="radio-fs-<?php echo e($fs->id); ?>"
                                        style="color: <?php echo e($fs->color); ?>;"><?php echo e($fs->status); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-span-9" style="color: <?php echo e($faktur->fakturstatus->color); ?>;">
                        <?php echo e($faktur->fakturstatus->status); ?>

                    </div>
                <?php endif; ?>
                <div class="col-span-3 place-self-start">Pesanan</div>
                <div class="col-span-9">
                    <table class="admin-table">
                        <tr>
                            <th>Qty</th>
                            <th>Gambar</th>
                            <th>Nama</th>
                            <th>Harga</th>
                            <th>Subtotal</th>
                        </tr>
                        <?php $__currentLoopData = $faktur->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->jumlah); ?></td>
                                <?php if($item->product): ?>
                                    <td>
                                        <img src="<?php echo e(asset('uploads/' . $item->product->image)); ?>"
                                            class="h-vh-10 mx-auto">
                                    </td>
                                    <td> [<?php echo e($item->kode_produk . '-' . $item->kode_produk_stock); ?>]
                                        <?php echo e($item->product->nama_produk); ?></td>
                                <?php else: ?>
                                    <td><img src="<?php echo e(asset('svg/images.svg')); ?>" class="h-vh-10 mx-auto"></td>
                                    <td> [<?php echo e($item->kode_produk . '-' . $item->kode_produk_stock); ?>]</td>
                                <?php endif; ?>
                                <td><?php echo e(AppHelper::rp($item->harga_satuan ?? 0)); ?></td>
                                <td><?php echo e(AppHelper::rp($item->subtotal ?? 0)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="4" class="text-right font-bold">Subtotal</td>
                            <td><?php echo e(AppHelper::rp($faktur->total_profit ?? 0)); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-right">Ongkos Kirim</td>
                            <td><?php echo e(AppHelper::rp($faktur->deliverycost ?? 0)); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-right">Diskon</td>
                            <td><?php echo e('- ' . AppHelper::rp($faktur->discount ?? 0)); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-right font-bold">Total</td>
                            <td><?php echo e(AppHelper::rp($faktur->total_pembayaran ?? 0)); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-span-3">Total Berat</div>
                <div class="col-span-9"><?php echo e($faktur->total_weight ?? 0); ?> gram</div>
                <div class="col-span-3 place-self-start">Pembeli</div>
                <div class="col-span-9">
                    <div class="flex flex-col">
                        <span class="font-bold"><?php echo e($faktur->user->name); ?></span>
                        <span><?php echo e($faktur->user->alamat); ?></span>
                        <span><?php echo e($faktur->user->kota); ?></span>
                        <span><?php echo e($faktur->user->propinsi . ' - ' . $faktur->user->country->name); ?></span>
                        <span><?php echo e($faktur->user->telp . '/' . $faktur->user->hp); ?></span>
                        <span><?php echo e($faktur->user->email); ?></span>
                    </div>
                </div>
                <div class="col-span-3 place-self-start">Penerima</div>
                <div class="col-span-9">
                    <div class="flex flex-col">
                        <span class="font-bold"><?php echo e($faktur->receiver->receiver_name); ?></span>
                        <span><?php echo e($faktur->receiver->address); ?></span>
                        <span><?php echo e($faktur->receiver->city); ?></span>
                        <span><?php echo e($faktur->receiver->phone . '/' . $faktur->receiver->hp); ?></span>
                    </div>
                </div>
                <div class="col-span-3">Pembayaran</div>
                <div class="col-span-9"><?php echo e($faktur->payment->description); ?></div>
                <div class="col-span-3 place-self-start text-red-500">Catatan Admin</div>
                <div class="col-span-9">
                    <textarea type="text" name="admin_note" id="input-content"
                        class="admin-input"><?php echo e($faktur->admin_note ?? null); ?></textarea>
                </div>
                <div class="col-span-12">
                    <button type="submit" class="admin-button">Simpan</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable({
                scrollX: true,
            });
        });
    </script>
    <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
    <script>
        ClassicEditor.create(document.querySelector('#input-content'), {
                mediaEmbed: {
                    previewsInData: true
                },
                removePlugins: ['CKFinderUploadAdapter', 'CKFinder', 'EasyImage', 'Image', 'ImageCaption', 'ImageStyle',
                    'ImageToolbar', 'ImageUpload', 'MediaEmbed', 'Table'
                ],
            }).then(editor => {})
            .catch(error => {
                console.error(error);
                console.error(error.stack);
            });
        ClassicEditor.editorConfig = function(config) {
            // misc options
            config.height = '350px';
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/faktur/edit.blade.php ENDPATH**/ ?>