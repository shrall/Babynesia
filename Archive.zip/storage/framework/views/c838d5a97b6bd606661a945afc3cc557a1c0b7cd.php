<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white p-4 flex items-center justify-between">
        <div class="flex flex-col gap-1">
            <span class="font-overpass text-3xl font-bold">Daftar Anggota</span>
        </div>
        <a href="<?php echo e(route('adminpage.member.create')); ?>" class="admin-button">Tambah Anggota</a>
    </div>
    <div class="w-full flex flex-col gap-y-4 p-4 hide-first invisible">
        <div class="admin-card">
            <div class="col-span-12">
                <table id="example" class="stripe hover" style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>E-Mail</th>
                            <th>Kota</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($user->no_user); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->kota); ?></td>
                                <td>
                                    <div class="flex items-center justify-center gap-2">
                                        <a target="blank" href="<?php echo e(route('adminpage.user.show', $user->no_user)); ?>"
                                            class="admin-button-info cursor-pointer">
                                            <span class="fa fa-fw fa-eye"></span>
                                        </a>
                                        <a target="blank" href="<?php echo e(route('adminpage.user.edit', $user->no_user)); ?>"
                                            class="admin-button-warning cursor-pointer">
                                            <span class="fa fa-fw fa-edit"></span>
                                        </a>
                                        <a onclick="event.preventDefault(); document.getElementById('delete-member-form-<?php echo e($user->no_user); ?>').submit();"
                                            class="admin-button-danger cursor-pointer">
                                            <span class="fa fa-fw fa-times"></span>
                                        </a>
                                        <form action="<?php echo e(route('adminpage.user.destroy', $user->no_user)); ?>"
                                            id="delete-member-form-<?php echo e($user->no_user); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input name="_method" type="hidden" value="DELETE">
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            var table = $('#example').DataTable({
                scrollX: true,
                "drawCallback": function(settings) {
                    $('.hide-first').removeClass('invisible');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/shop/member.blade.php ENDPATH**/ ?>