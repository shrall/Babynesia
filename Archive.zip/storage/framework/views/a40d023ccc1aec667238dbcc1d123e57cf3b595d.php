<nav class="bg-<?php echo e($color[0]); ?>-300 shadow-sm py-6">
    <div class="container mx-auto xl:px-32 hidden xl:block">
        <div class="flex justify-between items-center">
            <div class="flex items-center">
                <a href="/">
                    <h1 class="font-concert-one text-white text-5xl mr-5">TokoBayiFiv</h1>
                </a>
                <div class="py-2 px-4 rounded-full bg-white w-80">
                    <form action="<?php echo e(route('user.list_products')); ?>">

                        <div class="flex justify-between w-full items-center">
                            <input type="text" placeholder="Search by keyword" name="keyword"
                                value="<?php echo e(!empty($keyword) ? $keyword : ''); ?>"
                                class="w-full mr-3 appearance-none font-encode-sans bg-white outline-none text-gray-400">
                            <button type="submit">
                                <i class="fas fa-search text-gray-400"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="flex items-center">
                <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('user.user.index')); ?>" class=" ml-8 flex items-center">
                    <i class="fa fa-user-circle size text-4xl text-white"></i>
                    <div class="mx-3 font-encode-sans font-bold text-white"><?php echo e(Auth::user()->name); ?></div>
                </a>
                <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class=" ml-8 flex items-center">
                    <i class="fa fa-user-circle size text-4xl text-white"></i>
                    <div class="mx-3 font-encode-sans font-bold text-white">Log In</div>
                </a>
                <?php endif; ?>
                <a href="<?php echo e(route('user.cart.index')); ?>" class="ml-4 flex items-center">
                    <i class="fa fa-shopping-cart size text-4xl text-white"></i>
                    <div class="mx-3 font-encode-sans font-bold text-white">Cart</div>
                </a>
                <?php if(Auth::check()): ?>

                <?php else: ?>
                <a href="<?php echo e(route('register')); ?>"
                    class="ml-4 bg-white hover:bg-<?php echo e($color[2]); ?>-400 hover:text-white focus:ring-<?php echo e($color[2]); ?>-300 focus:ring-2 font-bold font-encode-sans text-<?php echo e($color[2]); ?>-400 px-4 py-2 rounded-full">
                    Daftar
                </a>

                <?php endif; ?>
            </div>
        </div>
        <ul class="mt-4">
            <?php if(!empty($page)&&$page == "home"): ?>
            <li class="inline-block font-encode-sans py-1 px-2 rounded-full bg-white text-<?php echo e($color[2]); ?>-400 font-bold">
                <a href="/" aria-expanded="true">
                    Home
                </a>
            </li>
            <?php else: ?>
            <li class="inline-block font-encode-sans text-white">
                <a href="/" aria-expanded="true">
                    Home
                </a>
            </li>
            <?php endif; ?>
            <?php if(!empty($page)&&$page == "about"): ?>
            <li class="ml-4 inline-block font-encode-sans py-1 px-2 rounded-full bg-white text-<?php echo e($color[2]); ?>-400 font-bold">
                <a href="" aria-expanded="true">
                    About
                </a>
            </li>
            <?php else: ?>
            <li class="ml-4 inline-block font-encode-sans text-white">
                <a href="" aria-expanded="true">
                    About
                </a>
            </li>
            <?php endif; ?>
            <?php if(!empty($page)&&$page == "article"): ?>
            <li class="ml-4 inline-block font-encode-sans py-1 px-2 rounded-full bg-white text-<?php echo e($color[2]); ?>-400 font-bold">
                <a href="<?php echo e(route('user.article')); ?>" aria-expanded="true">
                    Article
                </a>
            </li>
            <?php else: ?>
            <li class="ml-4 inline-block font-encode-sans text-white">
                <a href="<?php echo e(route('user.article')); ?>" aria-expanded="true">
                    Article
                </a>
            </li>
            <?php endif; ?>
            <?php if(!empty($page)&&$page == "faq"): ?>
            <li class="ml-4 inline-block font-encode-sans py-1 px-2 rounded-full bg-white text-<?php echo e($color[2]); ?>-400 font-bold">
                <a href="<?php echo e(route('user.faq.index')); ?>" aria-expanded="true">
                    FAQ
                </a>
            </li>
            <?php else: ?>
            <li class="ml-4 inline-block font-encode-sans text-white">
                <a href="<?php echo e(route('user.faq.index')); ?>" aria-expanded="true">
                    FAQ
                </a>
            </li>
            <?php endif; ?>
            <?php if(!empty($page)&&$page == "contact"): ?>
            <li class="ml-4 inline-block font-encode-sans py-1 px-2 rounded-full bg-white text-<?php echo e($color[2]); ?>-400 font-bold">
                <a href="<?php echo e(route('user.contact')); ?>" aria-expanded="true">
                    Contact
                </a>
            </li>
            <?php else: ?>
            <li class="ml-4 inline-block font-encode-sans text-white">
                <a href="<?php echo e(route('user.contact')); ?>" aria-expanded="true">
                    Contact
                </a>
            </li>
            <?php endif; ?>
            <?php if(!empty($page)&&$page == "guestbook"): ?>
            <li class="ml-4 inline-block font-encode-sans py-1 px-2 rounded-full bg-white text-<?php echo e($color[2]); ?>-400 font-bold">
                <a href="<?php echo e(route('user.guestbook.index')); ?>" aria-expanded="true">
                    Guestbook
                </a>
            </li>
            <?php else: ?>
            <li class="ml-4 inline-block font-encode-sans text-white">
                <a href="<?php echo e(route('user.guestbook.index')); ?>" aria-expanded="true">
                    Guestbook
                </a>
            </li>
            <?php endif; ?>
            <div class="group inline-block">

                <li class="peer ml-4 font-encode-sans text-white">
                    <div class="cursor-pointer">
                        Products
                    </div>
                </li>
                <div class="py-3 px-10 absolute">&nbsp;</div>
                <div
                    class="invisible group-hover:visible z-50 pb-6 mt-5 absolute left-0 bg-<?php echo e($color[0]); ?>-300 w-full mx-auto xl:px-40">
                    <ul class="grid grid-rows-5 grid-cols-3 justify-center w-8/10 mx-auto">
                        <?php $__currentLoopData = $allkategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="my-1 group">
                            <form action="<?php echo e(route('user.list_products')); ?>" method="get" id="kategorifilter"></form>
                            <input type="hidden" value="<?php echo e($kategori->no_kategori); ?>" name="filter"
                                form="kategorifilter">
                            <button type="submit" class="text-white font-encode-sans peer" form="kategorifilter"
                                <?php echo e(!empty($kategori->subcategories[0]) ? 'disabled' : ''); ?>>
                                <?php echo e($kategori->nama_kategori); ?>

                            </button>
                            <ul class="hidden ml-2 text-gray-400 pt-1 hover:block absolute peer-hover:block">
                                <?php $__currentLoopData = $subkategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($sub->kategori_id == $kategori->no_kategori): ?>
                                <form action="<?php echo e(route('user.list_products')); ?>" method="" id="subkategori<?php echo e($sub->child_id); ?>"></form>
                                <input type="hidden" name="subfilter" value="<?php echo e($sub->child_id); ?>" form="subkategori<?php echo e($sub->child_id); ?>">
                                <input type="hidden" name="filter" value="<?php echo e($kategori->no_kategori); ?>"
                                    form="subkategori<?php echo e($sub->child_id); ?>">
                                <li class="bg-neutral-100 p-2 hover:bg-white text-gray-400 hover:text-<?php echo e($color[2]); ?>-400 first:rounded-t-md last:rounded-b-md">
                                    <button type="submit" form="subkategori<?php echo e($sub->child_id); ?>"
                                        class="text-left appearance-none block whitespace-no-wrap"><?php echo e($sub->child_name); ?></button>
                                </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </ul>


    </div>

    <div class="xl:hidden sm:px-10 px-3">
        <div class="flex justify-between items-center">
            <div>
                <input type="checkbox" id="menu" class="hidden checked:">
                <label for="menu" class="flex items-center cursor-pointer">
                    <i class="fas fa-bars text-2xl text-white"></i>
                    <h6 class="ml-2 text-white font-bold">
                        Menu
                    </h6>
                </label>
            </div>
            <h1 class="text-3xl font-concert-one text-white">
                TokoBayiFiv
            </h1>
            <?php if(Auth::check()): ?>
            <a href="<?php echo e(route('user.cart.index')); ?>" class="flex items-center">
                <i class="fas fa-shopping-cart text-2xl text-white"></i>
                <h6 class="ml-2 text-white font-bold">
                    Cart
                </h6>
            </a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="flex items-center">
                <i class="fas fa-shopping-cart text-2xl text-white"></i>
                <h6 class="ml-2 text-white font-bold">
                    Cart
                </h6>
            </a>
            <?php endif; ?>
        </div>
        <div class="mt-3">
            <div class="py-3 px-4 rounded-full bg-white w-full">
                <div class="flex justify-between w-full items-center">
                    <input type="text" placeholder="Search by keyword"
                        class="w-full mr-3 appearance-none font-encode-sans bg-white outline-none text-gray-400">
                    <button type="submit">
                        <i class="fas fa-search text-gray-400"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="bgmenu xl:hidden fixed bg-slate-900 h-screen opacity-20 w-full -left-full top-0">
    <label for="menu" class="inline-block w-full h-full"></label>
</div>
<div class="transition-all duration-300 menulist xl:hidden sm:w-3/4 w-5/6 h-screen fixed -left-full top-0">
    <div class="bg-<?php echo e($color[0]); ?>-300 py-4 w-full">
        <div class="flex justify-between px-4">
            <div class="flex items-center">
                <label for="menu" class="flex items-center cursor-pointer">
                    <i class="fas fa-times sm:text-4xl text-3xl text-white"></i>
                </label>
                <?php if(Auth::checK()): ?>
                <a href="<?php echo e(route('user.user.index')); ?>" class="ml-5 flex items-center">
                    <i class="fa fa-user-circle size sm:text-4xl text-3xl text-white"></i>
                    <div class="mx-3 font-encode-sans font-bold text-white text-sm sm:text-base">
                        <?php echo e(Auth::user()->name); ?>

                    </div>
                </a>
                <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="ml-5 flex items-center">
                    <i class="fa fa-user-circle size sm:text-4xl text-3xl text-white"></i>
                    <div class="mx-3 font-encode-sans font-bold text-white text-sm sm:text-base">Log In</div>
                </a>
                <?php endif; ?>
            </div>
            <?php if(Auth::checK()): ?>

            <?php else: ?>
            <a href="<?php echo e(route('register')); ?>"
                class="py-3 px-5 bg-white text-<?php echo e($color[2]); ?>-400 font-bold font-encode-sans hover:bg-<?php echo e($color[2]); ?>-400 hover:text-white focus:ring-<?php echo e($color[2]); ?>-300 focus:ring-2 rounded-full text-sm sm:text-base">Daftar</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="bg-white py-4 px-4 h-full overflow-y-auto">
        <a href="/">
            <div class="my-3 font-encode-sans font-bold <?php echo e(!empty($page)&&$page == "home" ? 'text-'.$color[1].'-500' : 'text-slate-900'); ?> hover:text-<?php echo e($color[1]); ?>-500">
                Home
            </div>
        </a>
        <hr>
        <a href="">
            <div class="my-3 font-encode-sans font-bold <?php echo e(!empty($page)&&$page == "about" ? 'text-'.$color[1].'-500' : 'text-slate-900'); ?> hover:text-<?php echo e($color[1]); ?>-500">
                About
            </div>
        </a>
        <hr>
        <a href="<?php echo e(route('user.article')); ?>">
            <div class="my-3 font-encode-sans font-bold <?php echo e(!empty($page)&&$page == "article" ? 'text-'.$color[1].'-500' : 'text-slate-900'); ?> hover:text-<?php echo e($color[1]); ?>-500">
                Article
            </div>
        </a>
        <hr>
        <a href="<?php echo e(route('user.faq.index')); ?>">
            <div class="my-3 font-encode-sans font-bold <?php echo e(!empty($page)&&$page == "faq" ? 'text-'.$color[1].'-500' : 'text-slate-900'); ?> hover:text-<?php echo e($color[1]); ?>-500">
                FAQ
            </div>
        </a>
        <hr>
        <a href="<?php echo e(route('user.guestbook.index')); ?>">
            <div class="my-3 font-encode-sans font-bold <?php echo e(!empty($page)&&$page == "contact" ? 'text-'.$color[1].'-500' : 'text-slate-900'); ?> hover:text-<?php echo e($color[1]); ?>-500">
                Contact
            </div>
        </a>
        <hr>
        <a href="<?php echo e(route('user.guestbook.index')); ?>">
            <div class="my-3 font-encode-sans font-bold <?php echo e(!empty($page)&&$page == "guestbook" ? 'text-'.$color[1].'-500' : 'text-slate-900'); ?> hover:text-<?php echo e($color[1]); ?>-500">
                Guestbook
            </div>
        </a>
        <hr>
        <a href="">
            <div class="my-3 font-encode-sans font-bold text-slate-900 hover:text-<?php echo e($color[1]); ?>-500">
                Products
            </div>
        </a>
        <div class="ml-4">
            <ul class="font-encode-sans text-slate-900 text-sm md:text-base">
                <?php $__currentLoopData = $allkategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="my-1">
                    <form action="<?php echo e(route('user.list_products')); ?>" method="get">
                        <input type="hidden" value="<?php echo e($kategori->no_kategori); ?>" name="filter">
                        <button type="submit" class="text-slate-900 hover:text-<?php echo e($color[1]); ?>-500 font-encode-sans"
                            <?php echo e(!empty($kategori->subcategories[0]) ? 'disabled' : ''); ?>>
                            <?php echo e($kategori->nama_kategori); ?>

                        </button>
                    </form>
                    <?php $__currentLoopData = $subkategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sub->kategori_id == $kategori->no_kategori): ?>
                    <form action="<?php echo e(route('user.list_products')); ?>" method="">
                        <input type="hidden" name="subfilter" value="<?php echo e($sub->child_id); ?>">
                        <input type="hidden" name="filter" value="<?php echo e($kategori->no_kategori); ?>">
                        <ul class="ml-2 text-gray-400 pt-1 space-y-1 hover:text-<?php echo e($color[1]); ?>-500">
                            <li class="appearance-none block whitespace-no-wrap">
                                <button type="submit" class="text-left"><?php echo e($sub->child_name); ?></button>
                            </li>
                        </ul>
                    </form>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>




<script>
    const checkbox = document.querySelector('#menu');
    const menulist = document.querySelector('.menulist');
    const bgmenu = document.querySelector('.bgmenu');

    checkbox.addEventListener('click', function () {
        if (checkbox.checked) {
            menulist.classList.remove('-left-full');
            menulist.classList.add('left-0');
            bgmenu.classList.remove('-left-full');
            bgmenu.classList.add('left-0');
        } else {
            menulist.classList.remove('left-0');
            menulist.classList.add('-left-full');
            bgmenu.classList.remove('left-0');
            bgmenu.classList.add('-left-full');
        }
    });

</script>
<?php /**PATH /Users/shrall/Sites/babynesia/resources/views/inc/navbar1.blade.php ENDPATH**/ ?>