<?php $__env->startSection('content'); ?>
    <div class="w-full bg-white mb-2 p-4">
        <span class="font-concert-one text-3xl font-bold">Tambah Buku Tamu</span>
    </div>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <div class="admin-card mb-2">
            <div class="col-span-3">Nama</div>
            <div class="col-span-9 flex items-center gap-x-2">:
                <input type="text" name="" id="" class="bg-gray-200">
            </div>
            <div class="col-span-3">Gambar</div>
            <div class="col-span-9 flex flex-col gap-2">
                <div class="flex gap-2">
                    : <img src="<?php echo e(asset('svg/images.svg')); ?>" class="px-4 h-vh-20 bg-gray-300" id="preview-gallery-image">
                    <input type="file" name="" id="gallery-image" class="invisible w-2"
                        onchange="loadFile(event, 'gallery-image')" accept="image/*" required>
                </div>
                <div class="flex mx-2">
                    <label for="gallery-image" class="admin-button">Upload Gambar</label>
                </div>
            </div>
            <div class="col-span-12 flex flex-col gap-y-2">
                <div class="flex">
                </div>
            </div>
            <div class="col-span-12 text-center">
                <button type="submit" class="admin-button">Simpan</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
    <script>
        ClassicEditor.create(document.querySelector('#input-content'), {
                mediaEmbed: {
                    previewsInData: true
                },
                removePlugins: ['CKFinderUploadAdapter', 'CKFinder', 'EasyImage', 'Image', 'ImageCaption', 'ImageStyle',
                    'ImageToolbar', 'ImageUpload', 'MediaEmbed', 'Table'
                ],
            }).then(editor => {})
            .catch(error => {
                console.error(error);
                console.error(error.stack);
            });
        ClassicEditor.editorConfig = function(config) {
            // misc options
            config.height = '350px';
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shrall/Sites/babynesia/resources/views/admin/content/gallery_create.blade.php ENDPATH**/ ?>