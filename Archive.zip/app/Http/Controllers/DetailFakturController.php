<?php

namespace App\Http\Controllers;

use App\Models\DetailFaktur;
use Illuminate\Http\Request;

class DetailFakturController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('user.invoice');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DetailFaktur  $detailFaktur
     * @return \Illuminate\Http\Response
     */
    public function show(DetailFaktur $detailFaktur)
    {
        return view('user.invoice');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DetailFaktur  $detailFaktur
     * @return \Illuminate\Http\Response
     */
    public function edit(DetailFaktur $detailFaktur)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DetailFaktur  $detailFaktur
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetailFaktur $detailFaktur)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DetailFaktur  $detailFaktur
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetailFaktur $detailFaktur)
    {
        //
    }
}
