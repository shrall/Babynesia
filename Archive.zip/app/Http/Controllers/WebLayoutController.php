<?php

namespace App\Http\Controllers;

use App\Models\WebLayout;
use Illuminate\Http\Request;

class WebLayoutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\WebLayout  $webLayout
     * @return \Illuminate\Http\Response
     */
    public function show(WebLayout $webLayout)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\WebLayout  $webLayout
     * @return \Illuminate\Http\Response
     */
    public function edit(WebLayout $webLayout)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\WebLayout  $webLayout
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, WebLayout $webLayout)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\WebLayout  $webLayout
     * @return \Illuminate\Http\Response
     */
    public function destroy(WebLayout $webLayout)
    {
        //
    }
}
