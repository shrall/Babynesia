<?php

namespace App\Http\Controllers;

use App\Models\SitesAdmin;
use Illuminate\Http\Request;

class SitesAdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SitesAdmin  $sitesAdmin
     * @return \Illuminate\Http\Response
     */
    public function show(SitesAdmin $sitesAdmin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SitesAdmin  $sitesAdmin
     * @return \Illuminate\Http\Response
     */
    public function edit(SitesAdmin $sitesAdmin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SitesAdmin  $sitesAdmin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SitesAdmin $sitesAdmin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SitesAdmin  $sitesAdmin
     * @return \Illuminate\Http\Response
     */
    public function destroy(SitesAdmin $sitesAdmin)
    {
        //
    }
}
